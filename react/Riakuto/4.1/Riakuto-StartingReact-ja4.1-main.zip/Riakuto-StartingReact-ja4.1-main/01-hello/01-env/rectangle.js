class Rectangle {
  constructor(height, width) {
    this.height = height;
    this.width = width;
  }

  getArea = () => this.height * this.width;
}
