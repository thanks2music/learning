const property1 = 'car';
const property2 = 'pc';

const myBelongings = {
  [property1]: 'Wagon R',
};
myBelongings[property2] = 'MacBook Pro 16-inch';

console.log(myBelongings);
