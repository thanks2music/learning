const fuu = {
  bar: "bar",
  baz() {
    console.log("I am `baz` method");
  },
};

fuu.baz();
