const raise = (n, m = 2) => n ** m;

console.log(raise(2, 3));
console.log(raise(3));
