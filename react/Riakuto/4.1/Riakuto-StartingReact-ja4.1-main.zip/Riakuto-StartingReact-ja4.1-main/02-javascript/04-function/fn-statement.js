console.log(fn());

function fn() {
  return 'foo';
}

function fn() {
  return 'bar';
}
