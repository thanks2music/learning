function showAllArgs(...args) {
  console.log(args);
}

showAllArgs("Moon", "Mercury", "Mars", "Jupiter", "Venus");
