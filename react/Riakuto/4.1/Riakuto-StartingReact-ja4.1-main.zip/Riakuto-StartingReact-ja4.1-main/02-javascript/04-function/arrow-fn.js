const plusOne = function (n) {
  return n + 1;
}

const addOne = (n) => {
  return n + 1;
};

const increment = n => n + 1;

console.log(plusOne(4));
console.log(addOne(4));
console.log(increment(4));
