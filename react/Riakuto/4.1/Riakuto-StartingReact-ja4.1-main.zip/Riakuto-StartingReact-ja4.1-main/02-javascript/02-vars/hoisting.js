a = 100;
console.log(a);

var a;
