let COUNT = 0;

function increment() {
  return (COUNT += 1);
}
