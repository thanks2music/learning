// let friendship;

if (true) {
  const he = "Kakeru";

  function saveHim() {
    console.log(`${he} is alive!`);
  }
  // friendship = saveHim;
}

// friendship();
